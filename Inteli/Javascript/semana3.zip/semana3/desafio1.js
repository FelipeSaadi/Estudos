const GRAVITY = 10
function calcV0(){
    let v0 = document.getElementById("velocity").value
    return v0
}
function calcT() {
    let v = calcV0()
    let t = v/GRAVITY
    showT(t)
}
function calcHmax() {
    let t = calcV0()
    hmax = t^2/(2*GRAVITY)
    showHmax(hmax)
}
function calc() {
    calcT()
    calcHmax()
}
function showT(value) {
    document.getElementById("resultT").innerText = "O resultado de V0/g é: "+value
}
function showHmax(value) {
    document.getElementById("resultHmax").innerText = "O resultado de V0^2/2g é: "+value
}
// let previous
// function changeChallenge(value) {
//     // let challenges = document.querySelectorAll(".challenges")
//     // for(i = 0; i < challenges.length; i++) {
//     //     challenges[i].style.display = "none"
//     // }
//     if(previous) {
//         console.log(previous)
//         previous.style.display = "none"
//     }
//     // document.querySelector("#"+value).style.display = "block"
//     previous = document.getElementById(value)
//     previous.style.display = "block"
// }

$(function() {
    $('#challenge-selection').change(function(){
    $('.challenges').hide();
    $('#' + $(this).val()).show();
    console.log($('#' + $(this).val()))
    });
});